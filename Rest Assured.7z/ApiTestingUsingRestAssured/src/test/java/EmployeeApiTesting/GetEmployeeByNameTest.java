package EmployeeApiTesting;

import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.junit.jupiter.api.Assertions;

public class GetEmployeeByNameTest {

    static Logger logger = Logger.getLogger(GetEmployeeByNameTest.class);

    public static void main(String[] args) {

        // Create Base URL
        RestAssured.baseURI = "http://localhost:7777/employee";

        // Instantiation of Rest Assured API
        RequestSpecification requestSpecification = RestAssured.given();

        // Invoking API which has Path param
        Response response = requestSpecification.request(Method.GET, "/getByName/Deepa");

        // Get Status Code
        int statusCode = response.getStatusCode();
        System.out.println("Response status code is " + statusCode);

        // Get Headers
        Headers header = response.getHeaders();
        System.out.println("Headers of the response body are " + header);

        // Get Response Body
        ResponseBody body = response.getBody();
        body.prettyPrint();
        logger.info("Response Body is " + body.asString());

        // Compare Data
        String responseBodyAsString = response.getBody().asString();
        Assertions.assertTrue(responseBodyAsString.contains("Deepa"));

    }
}
