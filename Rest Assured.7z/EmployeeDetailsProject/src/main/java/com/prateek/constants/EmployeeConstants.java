package com.prateek.constants;

public class EmployeeConstants {


    public static final String EMPLOYEE_DATA ="{\n" +
            "\"employeeDetails\":[\n" +
            "    {\n" +
            "        \"empName\": \"Prateek\",\n" +
            "        \"empId\": \"166675\",\n" +
            "        \"empLocation\": \"Bangalore\"\n" +
            "    },\n" +
            "    {\n" +
            "        \"empName\": \"Deepa\",\n" +
            "        \"empId\": \"166676\",\n" +
            "        \"empLocation\": \"Pune\"\n" +
            "    }\n" +
            "]\n" +
            "}";
}
