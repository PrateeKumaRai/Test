package com.prateek.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.prateek.model.Employee;
import com.prateek.model.EmployeeDetail;
import com.prateek.service.EmployeeDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeDetailController {

    @Autowired
    private EmployeeDetailService employeeDetailService;

    @GetMapping("/getAll")
    public ResponseEntity<Object> getAllEmployee() throws JsonProcessingException {

        Employee employee = employeeDetailService.getAllEmployee();
        return new ResponseEntity<>(employee, HttpStatus.OK);

    }


    @GetMapping("/getById")
    public ResponseEntity<Object> getEmployeeById(@RequestParam(name = "empId", required = false) String empId) throws JsonProcessingException {

        EmployeeDetail employeeDetail = employeeDetailService.getAllEmployeeById(empId);
        return new ResponseEntity<>(employeeDetail, HttpStatus.OK);

    }

    @GetMapping("/getByName/{empName}")
    public ResponseEntity<Object> getEmployeeByName(@PathVariable String empName) throws JsonProcessingException {

        EmployeeDetail employeeDetail = employeeDetailService.getAllEmployeeByName(empName);
        return new ResponseEntity<>(employeeDetail, HttpStatus.OK);

    }

    @PostMapping ("/saveEmployee")
    public ResponseEntity<Object> saveEmployeeDetails(@RequestBody EmployeeDetail employeeDetail)  {

        EmployeeDetail employeeDetailResponse = employeeDetailService.saveEmployeeDetails(employeeDetail);
        return new ResponseEntity<>(employeeDetailResponse, HttpStatus.OK);

    }

}
