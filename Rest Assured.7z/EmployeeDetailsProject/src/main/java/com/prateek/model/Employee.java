package com.prateek.model;

import java.util.List;

public class Employee {

    private List<EmployeeDetail> employeeDetails;

    public List<EmployeeDetail> getEmployeeDetails() {
        return employeeDetails;
    }

    public void setEmployeeDetails(List<EmployeeDetail> employeeDetails) {
        this.employeeDetails = employeeDetails;
    }
}
