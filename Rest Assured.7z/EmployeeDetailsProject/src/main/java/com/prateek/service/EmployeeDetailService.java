package com.prateek.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prateek.constants.EmployeeConstants;
import com.prateek.model.Employee;
import com.prateek.model.EmployeeDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeDetailService {

    @Autowired
    public ObjectMapper objectMapper;

    public Employee getAllEmployee() throws JsonProcessingException {

        String json = EmployeeConstants.EMPLOYEE_DATA;
        Employee employee = objectMapper.readValue(json, Employee.class);
        return employee;

    }


    public EmployeeDetail getAllEmployeeById(String empId) throws JsonProcessingException {

        String json = EmployeeConstants.EMPLOYEE_DATA;
        Employee employee = objectMapper.readValue(json, Employee.class);
        List<EmployeeDetail> employeeDetailList = employee.getEmployeeDetails();
        EmployeeDetail employeeDetailReponse = new EmployeeDetail();
        for (EmployeeDetail employeeDetail : employeeDetailList) {
            if (empId.equalsIgnoreCase(employeeDetail.getEmpId())) {
                employeeDetailReponse.setEmpId(employeeDetail.getEmpId());
                employeeDetailReponse.setEmpLocation(employeeDetail.getEmpLocation());
                employeeDetailReponse.setEmpName(employeeDetail.getEmpName());
            }
        }
        return employeeDetailReponse;

    }

    public EmployeeDetail getAllEmployeeByName(String empName) throws JsonProcessingException {

        String json = EmployeeConstants.EMPLOYEE_DATA;
        Employee employee = objectMapper.readValue(json, Employee.class);
        List<EmployeeDetail> employeeDetailList = employee.getEmployeeDetails();
        EmployeeDetail employeeDetailReponse = new EmployeeDetail();
        for (EmployeeDetail employeeDetail : employeeDetailList) {
            if (empName.equalsIgnoreCase(employeeDetail.getEmpName())) {
                employeeDetailReponse.setEmpId(employeeDetail.getEmpId());
                employeeDetailReponse.setEmpLocation(employeeDetail.getEmpLocation());
                employeeDetailReponse.setEmpName(employeeDetail.getEmpName());
            }
        }
        return employeeDetailReponse;

    }

    public EmployeeDetail saveEmployeeDetails(EmployeeDetail employee) {

        EmployeeDetail employeeDetail = new EmployeeDetail();
        employeeDetail.setEmpName(employee.getEmpName());
        employeeDetail.setEmpLocation(employee.getEmpLocation());
        employeeDetail.setEmpId(employee.getEmpId());
        return employeeDetail;
    }

}
